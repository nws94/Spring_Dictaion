package com.dictation.vo;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class So_cdVO {
	private String dae_cd;
	private String so_cd;
	private String so_nm;
	private String use_yn;
	private String bigo;
	
}
